#pragma once
#define DECKMAXSIZE 25
#define AllCARDMAXSIZE 115